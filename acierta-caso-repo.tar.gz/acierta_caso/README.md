# Plan de Marketing Estratégico — Acierta by CAINCO

Caso técnico para la posición de **Subgerente de Marketing Estratégico** de CAINCO (Cámara de Industria, Comercio, Servicios y Turismo de Santa Cruz). Plan de marketing a 6 meses para la unidad de servicios empresariales **ACIERTA**, resuelto con un sistema multi-agente de análisis.

## 📦 Entregable

**[`Plan_Marketing_Acierta_CAINCO.pptx`](./Plan_Marketing_Acierta_CAINCO.pptx)** — Presentación de 10 slides que cubre los tres ejes del caso:

1. **Diagnóstico** — auditoría digital (3 fortalezas / 3 debilidades), mapa competitivo y contexto macro.
2. **Estrategia** — arquitectura de marca, objetivos SMART con KPIs y estrategia de contenidos LinkedIn.
3. **Quick wins y hoja de ruta** — 3 acciones a 60 días, cronograma de 6 meses y criterios de éxito.

## 🧠 Cómo se construyó

El análisis se resolvió con un sistema de **1 orquestador + 8 agentes especializados** que comparten un *brief* vivo. Los agentes de diagnóstico usaron investigación web real (presencia digital de Acierta, competidores, datos macro de Bolivia 2026), no supuestos genéricos.

| Carpeta | Contenido |
|---|---|
| [`_brief/`](./_brief) | El *brief* compartido: hallazgos de los 8 agentes + storyline de las 10 slides. |
| [`00_orquestador/`](./00_orquestador) | Definición de roles de cada agente (prompts reutilizables). |
| [`build.js`](./build.js) | Script que genera el deck (`pptxgenjs`). Re-ejecutable. |

## 🔧 Regenerar el deck

```bash
npm install pptxgenjs react-icons react react-dom sharp
node build.js
```

## ⚠️ Nota

Las cifras de baseline (ej. "0 métricas", "25% de leads no-core") son supuestos de partida del caso. Reemplazar por datos reales de Acierta al disponer de ellos.

---
*Confidencial — preparado para proceso de selección ETIKA SRL.*
