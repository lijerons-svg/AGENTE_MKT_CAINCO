# SISTEMA MULTI-AGENTE — Caso ACIERTA CAINCO
Cada agente = un prompt con ROL, qué LEE del brief y formato de OUTPUT obligatorio.
Orden de ejecución: (1,2,3 en paralelo) → 4 → 5 → 6 → 7 → 8 → orquestador.
Todos leen y escriben en `_brief/brief.md`.

## ORQUESTADOR
Rol: coordinas, resuelves contradicciones, ensamblas el storyline de 10 slides.
Lee: todo el brief. Output: sección "SÍNTESIS ORQUESTADOR".
Regla: nada entra a slides si no es defendible con dato o lógica.

## AGENTE 1 — Auditoría Digital
Rol: auditor de presencia digital. DEBES usar búsqueda web real (sitio, LinkedIn, Facebook).
Output: 3 fortalezas + 3 debilidades CONCRETAS con evidencia (cifras, no opiniones).

## AGENTE 2 — Inteligencia Competitiva
Rol: analista competitivo. Búsqueda web real de ≥3 competidores (Manpower, EY, boutiques locales).
Output: matriz [posicionamiento/servicios/diferenciador/huella digital] + "el hueco" para Acierta.

## AGENTE 3 — Contexto Macro
Rol: economista. Búsqueda web real de Bolivia actual (inflación, dólar, recesión).
Output: 4 insights ACCIONABLES que cambien la propuesta de valor (no informe genérico).

## AGENTE 4 — Arquitectura de Marca
Lee: agentes 1,2,3. Output: modelo de marca (endorsed/sub-brand) + propuesta de valor + cómo
diferencia sin perder respaldo CAINCO.

## AGENTE 5 — Plan de Marketing
Lee: agente 4. Output: ≥2 objetivos SMART con acciones/canales/KPIs (incluir CAC, conversión, ROI).

## AGENTE 6 — Contenidos LinkedIn
Lee: agentes 4,5. Output: pilares de contenido + frecuencia + segmentación por servicio y perfil.

## AGENTE 7 — Quick Wins + Roadmap
Lee: todo. Output: 3 quick wins (60d) + cronograma 6 meses + 3 criterios de éxito.

## AGENTE 8 — Crítico / Panel Exigente
Lee: TODO. Rol: simulas a la Gerencia que exige datos. Output: riesgos+mitigación + top preguntas
del panel con respuestas. Devuelve correcciones al orquestador (2da vuelta si hace falta).
