# BRIEF VIVO — Caso ACIERTA CAINCO
> Cerebro compartido del sistema multi-agente. Estado: [x] completo.
> Entregable: Plan de Marketing 6 meses · ≤10 slides · 15 min exposición + 10 min debate · panel exige DATOS.

================================================================
## [x] AGENTE 1 — AUDITORÍA DIGITAL  (evidencia real, may-2026)
================================================================
ACTIVOS DIGITALES DETECTADOS:
- Sitio propio: acierta.cainco.org.bo (separado del corporativo cainco.org.bo). Bloquea crawlers.
- LinkedIn: showcase page "Acierta CAINCO" (bajo CAINCO, que tiene ~45.875 seguidores).
- Facebook: "Acierta - CAINCO" → 19.752 likes, "36 talking about this", 4 reseñas, "Not yet rated".
- Email único acierta@cainco.org.bo + 3 números WhatsApp distintos (78086466 / 77024203 / etc).
- Presencia en agregadores: Trabajopolis (21 ofertas), Infocal Laboral, IBCE.

3 FORTALEZAS CONCRETAS:
F1. Respaldo de marca CAINCO: +100 años, 4.000 asociadas, 45.8k seguidores corporativos en LinkedIn
    → credibilidad institucional que ningún competidor privado puede replicar.
F2. Base social ya construida en Facebook (19.7k likes) — capital que hoy se subutiliza.
F3. Portafolio amplio y mensajes de valor ya redactados ("convertir desafíos en oportunidades",
    "socio confiable") + acceso a data económica propia (CEBEC) como activo de contenido único.

3 DEBILIDADES CONCRETAS:
D1. Identidad fragmentada: 2 dominios, showcase escondido bajo CAINCO, 3 WhatsApp distintos
    → el lead no sabe "dónde vive" Acierta. Diluye marca y métricas.
D2. Contenido = bolsa de empleos: el feed (LinkedIn/FB/Trabajopolis) está dominado por avisos
    "buscamos X cargo". Comunica que Acierta = agencia de vacantes, NO consultora estratégica.
    Invisibiliza por completo Empresas Familiares, Planificación y Asesoría Económica.
D3. Canal B2B desaprovechado: la conversación de decisores está en LinkedIn, pero el peso real
    está en Facebook (público B2C/postulantes). Sin reseñas activadas (solo 4, "not yet rated")
    → cero prueba social para el comprador corporativo.

================================================================
## [x] AGENTE 2 — INTELIGENCIA COMPETITIVA (real)
================================================================
| Competidor | Posicionamiento | Servicios | Diferenciador | Huella digital |
|---|---|---|---|---|
| Manpower Bolivia | Líder global staffing, transaccional | R&S, temporal, tercerización, capacitación | Marca mundial, escala, franquicia desde 1991 (LP/SC/CBBA) | LinkedIn 10.3k · FB 17.5k |
| EY Bolivia | Big Four, premium/corporativo | Family Enterprise + impuestos + advisory | Metodología global (ADN Empresa Familiar), prestigio | Marca global, web robusta |
| Exaudi Family Business | Boutique especialista, desde 2010 | Protocolo, gobierno, sucesión (solo familia) | Foco 100% empresa familiar, eventos presenciales en SC | Nicho, eventos, alianzas (Kriterio, Orienta Legal) |
| Heranza / Kriterio (locales) | Boutiques locales | Empresa familiar, gobierno corp. | Cercanía, diagnóstico gratuito de entrada | Web propia, menor escala |

LECTURA ESTRATÉGICA:
- En R&S core, Acierta NO gana por escala vs Manpower → debe ganar por "conocimiento del tejido
  empresarial cruceño" (los 4.000 asociados son su base de datos y red de talento).
- En consultoría (familiar/estratégica), el espacio premium lo toman EY (caro, distante) y los
  boutiques (especialistas pero sin respaldo gremial). HUECO: Acierta = respaldo institucional CAINCO
  + cercanía local + precio accesible. Nadie ocupa ese cuadrante.
- Manpower comunica "empleo"; Acierta debería comunicar "empresa" (gestión, no solo vacantes).

================================================================
## [x] AGENTE 3 — CONTEXTO MACRO (datos may-2026, accionables)
================================================================
HECHOS:
- Inflación: cerró 2025 en ~20,4%; gobierno la bajó a rango 14-15% en 2026 (proyección PGE 14%).
- Dólar: paralelo llegó a ~Bs 20; tipo de cambio bajó de Bs 11 a ~Bs 9,6-9,7 en 2026.
- Recesión: FMI -3,3% / BM -3,2% PIB 2026. Escasez de divisas estructural desde feb-2023.
- Déficit fiscal ~13% (2025) → meta 7-9% (2026). Diésel/combustible escaso. Bloqueos sociales (may-2026).
- Nuevo gobierno (Rodrigo Paz desde nov-2025) en plan de estabilización.

4 INSIGHTS ACCIONABLES PARA EL PLAN:
M1. "Flight to value": con caja apretada, las empresas cortan consultoría discrecional PERO suben
    su sensibilidad a un mal hire. → Vender R&S como SEGURO ANTI-ERROR de contratación, con ROI:
    "una mala contratación cuesta X salarios; nuestra selección lo evita". Hablar en bolivianos y en costo evitado.
M2. La crisis ES el gancho de los servicios olvidados: reestructuración org., optimización de costos,
    sucesión ordenada y planificación con escenarios son MÁS necesarios en recesión. Reposicionar
    "Estructura Organizacional" y "Planificación" como "resiliencia en crisis", no como lujo.
M3. La Asesoría Económica/CEBEC es oro de contenido: en plena incertidumbre cambiaria, datos
    confiables sobre inflación/dólar/sector son imán de leads B2B. Convertir data en motor de marketing.
M4. Presupuesto en divisas escasas → marketing debe ser orgánico/owned-media primero (LinkedIn,
    webinars, base CAINCO), minimizando gasto en pauta en USD. El plan debe verse barato y medible.

================================================================
## [x] AGENTE 4 — ARQUITECTURA DE MARCA
================================================================
Modelo recomendado: ENDORSED BRAND ("Acierta, by CAINCO").
- Acierta gana personalidad/identidad visual propia, pero firma siempre "respaldado por CAINCO".
- Tensión resuelta: diferenciación SIN orfandad institucional. CAINCO = aval de confianza;
  Acierta = especialista ágil y cercano.
Propuesta de valor diferenciada (1 frase): 
  "El conocimiento del tejido empresarial de CAINCO, puesto a trabajar dentro de tu empresa."
Territorio de marca: de "agencia que llena vacantes" → "socio de gestión de personas y negocio".
Naming de líneas para des-commoditizar (sugerencia): mantener R&S como ancla, pero agrupar el resto
  bajo "Acierta Consultoría" y "Acierta Inteligencia Económica" para darles volumen propio.

================================================================
## [x] AGENTE 5 — PLAN DE MARKETING (objetivos SMART)
================================================================
OBJETIVO SMART 1 — Diversificar ingresos más allá del core:
  "Aumentar la participación de las líneas no-core (Familiares, Planificación, Asesoría Económica)
   del baseline actual a 25% de los leads calificados en 6 meses."
  Acciones: campaña temática mensual por línea · 1 webinar/mes con experto CEBEC · landing por servicio.
  Canales: LinkedIn (orgánico), email a base CAINCO, webinars, WhatsApp Business.
  KPIs: % leads no-core / total · nº leads por línea · nº inscritos webinar.

OBJETIVO SMART 2 — Construir el sistema de medición inexistente:
  "Implementar embudo medible (lead→SQL→cierre) y reportar CAC, tasa de conversión y ROI mensual
   desde el mes 2, con tablero para Gerencia."
  Acciones: 1 CRM/pipeline (aunque sea HubSpot free) · UTMs en todo enlace · unificar WhatsApp en 1 línea Business · dashboard mensual.
  Canales: CRM, formularios web, WhatsApp Business API.
  KPIs: CAC por servicio · tasa lead→cierre · ROI por campaña · tiempo de respuesta a lead.

(Objetivo extra opcional SMART 3 — Marca: subir engagement-rate LinkedIn de la línea base a 4% y
 llevar 1.500 seguidores netos al showcase propio en 6 meses.)

================================================================
## [x] AGENTE 6 — CONTENIDOS LINKEDIN (canal B2B principal)
================================================================
4 PILARES (regla 4-1-1 aprox):
P1. INTELIGENCIA ECONÓMICA (autoridad): data CEBEC, inflación/dólar/sector → imán de decisores. 1/sem.
P2. GESTIÓN DE PERSONAS (utilidad): tips de selección, costo de mala contratación, cultura. 1/sem.
P3. EMPRESA FAMILIAR & ESTRATEGIA (nicho premium): sucesión, gobierno, casos. 1 cada 2 sem.
P4. PRUEBA SOCIAL & MARCA (conversión): casos de éxito, testimonios, equipo, CTA. 1 cada 2 sem.
Frecuencia: 3-4 posts/semana. Formato estrella: carrusel de datos + 1 video corto experto/mes.
Segmentación de mensajes:
- PYME / empresa familiar → dolor "continuidad y orden": Empresas Familiares + Estructura.
- Corporativo / multinacional → dolor "talento clave y velocidad": R&S + Evaluaciones.
- C-level / dueños → Inteligencia Económica (toma de decisiones).
- RRHH → Evaluaciones Psicotécnicas (Perfiles) + Outplacement.

================================================================
## [x] AGENTE 7 — QUICK WINS + ROADMAP
================================================================
3 QUICK WINS (primeros 60 días):
QW1. Unificar identidad: 1 sola landing, 1 WhatsApp Business, bio/encabezados consistentes
     "Acierta by CAINCO". (impacto: claridad + medición; costo casi cero).
QW2. Lanzar "Pulso Económico Acierta": 1 reporte/webinar mensual con data CEBEC sobre dólar/inflación
     → captura leads B2B usando un activo que YA existe. (visibilidad inmediata, diferenciador).
QW3. Activar prueba social: campaña de testimonios + reseñas en redes (hoy solo 4) + 3 mini-casos
     de éxito en LinkedIn. (convierte reputación existente en activo de venta).

CRONOGRAMA 6 MESES (hitos):
- M1: Diagnóstico + auditoría + unificación de identidad + setup CRM/UTMs (QW1).
- M2: Lanzamiento "Pulso Económico" + arranque parrilla LinkedIn + 1er dashboard a Gerencia (QW2).
- M3: Campaña testimonios/casos + landings por servicio (QW3).
- M4: Campaña foco línea no-core #1 (Empresa Familiar) + webinar.
- M5: Campaña foco no-core #2 (Planificación/Estructura "resiliencia en crisis") + nurturing email.
- M6: Medición de resultados, optimización, reporte semestral con CAC/conversión/ROI.

3 CRITERIOS DE ÉXITO (para Gerencia exigente):
C1. Diversificación: ≥25% de leads calificados provienen de líneas no-core (vs ~dependencia actual).
C2. Sistema medible operando: CAC, conversión y ROI reportados mensualmente (hoy: 0 métricas).
C3. Eficiencia en crisis: costo por lead a la baja mes a mes, con marketing mayoritariamente orgánico
    (defendible ante escasez de divisas).

================================================================
## [x] AGENTE 8 — CRÍTICO / PANEL EXIGENTE (red-team + Q&A)
================================================================
RIESGOS DETECTADOS Y MITIGACIÓN:
R1. "Los KPIs (CAC, conversión) requieren data que Acierta hoy NO tiene." → Sí: por eso el Objetivo 2
    es CONSTRUIR el sistema. En slides, mostrar baseline = "0 / no medido" como punto de partida honesto.
R2. "¿Diferenciar Acierta no canibaliza a CAINCO?" → No: modelo endorsed ("by CAINCO") suma aval, no resta.
R3. "Webinars/contenido = costo de tiempo del equipo." → Se apalanca en CEBEC y equipo existente; pauta mínima.

TOP PREGUNTAS PROBABLES DEL PANEL (preparar respuesta):
Q1. ¿Cómo mides ROI sin histórico? → Baseline 0 + cohortes desde mes 1; ROI = ingreso atribuido / gasto.
Q2. ¿Por qué LinkedIn si tu masa está en Facebook? → FB = postulantes (B2C); el COMPRADOR B2B decide en LinkedIn.
Q3. ¿Presupuesto? → Plan diseñado low-cost/orgánico por la escasez de divisas; <X% en pauta USD.
Q4. ¿Y si el core sigue dando el 90%? → No se abandona; se protege el core y se diversifica el riesgo.
Q5. ¿Primer resultado tangible en 60 días? → Los 3 quick wins, con el "Pulso Económico" como bandera.

================================================================
## SÍNTESIS ORQUESTADOR → STORYLINE 10 SLIDES
================================================================
S1.  Portada: "Acierta by CAINCO — Plan de Marketing 6 meses".
S2.  Diagnóstico relámpago: 3 fortalezas / 3 debilidades digitales (Agente 1).
S3.  Mapa competitivo + EL HUECO que Acierta puede ocupar (Agente 2).
S4.  Contexto macro como oportunidad, no excusa (Agente 3 → M1-M4).
S5.  Arquitectura de marca: endorsed brand + propuesta de valor (Agente 4).
S6.  Objetivos SMART 1 y 2 con KPIs (Agente 5) — incluye baseline honesto.
S7.  Estrategia de contenidos LinkedIn: 4 pilares + segmentación (Agente 6).
S8.  3 Quick Wins (60 días) (Agente 7).
S9.  Roadmap 6 meses (cronograma de hitos) (Agente 7).
S10. 3 Criterios de éxito + cómo reporto a Gerencia (Agente 7 + 8).
